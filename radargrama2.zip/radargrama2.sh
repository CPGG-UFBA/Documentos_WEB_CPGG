#!/bin/sh
#
# Programa exemplo para desenhar um radargrama
#######################################################################
# O arquivo de entrada abaete1.grd foi obtido a partir de um arquivo
# tipo traceplot, acesso sequencial, por meio do programa
# "trcplt2gmt".   Tecle trcplt2gmt que aparecerao instrucoes sobre
# a sua propria utilizacao.
#
FILE=abaete1.grd
PSFILE=abaete2.ps
CPTFILE=abaete2.cpt
#######################################################################
#
rm -f .gmtdefaults .gmtcommands
#
# Uma lista desses parametros pode ser obtida com "man gmtdefaults"
#
gmtset ANOT_FONT_SIZE 10 ANOT_FONT Helvetica-Oblique
gmtset LABEL_FONT Helvetica LABEL_FONT_SIZE 12
gmtset HEADER_FONT Helvetica-Narrow-BoldOblique HEADER_FONT_SIZE 12 
gmtset FRAME_PEN 2
gmtset X_ORIGIN 4 Y_ORIGIN 7.5
#######################################################################
# Uma dica para criar um arquivo de "cores" a partir dos dados, 
# fazendo uso das cores do arco-iris.
#
# Tecle "man grdhisteq" para uma descricao sobre o programa.
# O "awk" apos o "grdhisteq" tornam contiguas as faixas listadas
# pelo "grdhisteq".  As descontinuidades observadas em alguns casos
# devem ser resultados de "bugs" no programa "grdhisteq".
#
NINTERVAL=10
grdhisteq $FILE -C$NINTERVAL -D|\
awk '
BEGIN {line=0}
END {print cola "\t" colb}
{if (line==0) {line=1; cola=$1; colb= $2}
else {print cola "\t" (colb+$1)/2; cola=(colb+$1)/2; colb=$2}}' > temp1
#
makecpt -C1 -S"$NINTERVAL"c|egrep -v [#BF]|\
paste temp1 -|awk '{print $1,$4,$5,$6,$2,$8,$9,$10}' > $CPTFILE
#
rm -f temp1
#######################################################################
# Obtendo os valores de xmin, xmax, ymin, ymax
#
XMIN=`grdinfo $FILE|awk '/x_min:/{print $3}'`
XMAX=`grdinfo $FILE|awk '/x_min:/{print $5}'`
YMIN=`grdinfo $FILE|awk '/y_min:/{print $3}'`
YMAX=`grdinfo $FILE|awk '/y_min:/{print $5}'`
#######################################################################
# Gerando a secao
#
TITULO="Radargrama"
XTITL="Dist@!\303ancia (m)"
YTITL="Tempo (ns)"
#
gmtset GRID_PEN 1
#
LARGURA=12
ALTURA=6
#
psxy <<FIM -Jx1 -R0/14.6/0/9.1 -L -K -P >$PSFILE
0	0
14.6	0
14.6	9.1
0	9.1
FIM
#
grdimage $FILE -V -C$CPTFILE -JX$LARGURA/-$ALTURA -R$XMIN/$XMAX/$YMIN/$YMAX \
-B50f10:"$XTITL":/200g50:"$YTITL":/:".$TITULO":WN \
-X2 -Y.5 \
-O >> $PSFILE
#
#######################################################################
