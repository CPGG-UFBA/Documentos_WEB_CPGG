#!/bin/sh
##############################################################################
##############################################################################
# 
# Exemplo de procedimento para elaboracao de uma pseudo-secao tipica
# do metodo da polarizacao eletrica induzida, com a utilizacao do
# padrao de cores do arco-iris.
#
# H.K.Sato (mar/1996), (rev. ago/1996)
#
##############################################################################
##############################################################################
# Para evitar interferencias com outras utilizacoes do pacote GMT, ocorridas
# no diretorio corrente, remove-se os arquivos .gmtdefaults e .gmtcommands
#
rm -f .gmtdefaults .gmtcommands
#
##############################################################################
# Estabelecendo parametros desejados.  Uma explicacao de cada parametro
# pode ser obtida com o comando "man gmtdefaults"
#
gmtset ANOT_FONT Helvetica-Oblique ANOT_FONT_SIZE 12  DOTS_PR_INCH 600
gmtset LABEL_FONT Helvetica-BoldOblique LABEL_FONT_SIZE 12
##############################################################################
# Variaveis:
#
XMIN=0
XMAX=630
YMIN=-121
XINC=15
TITULO="Pseudo-se@!\313c@!\304ao de resistividade aparente"
#
CORES=ex01.cpt
PSFILE=ex01.ps
########################################################################
# "makecpt" constroi uma escala de cores e valores de contorno,
# "egrep" elimina as linhas-comentario e as duas ultimas, e
# "awk" acrescenta "L" aos finais das linhas cujas primeiras colunhas
#	contenham um numero multiplo de 200, ou "U" `a linha cuja primeira
#	coluna tenha 1700.
#	Essas simbologias L e U indicam ao "pscontour" e "psscale" quais 
#	contornos devem ser rotulados.
#
makecpt -C100 -S18c -M900|\
egrep -v [#BF]|\
awk '{if ($1%200==0) print $0"\tL" 
else if ($1==1700) print $0"\tU" 
else print}' > $CORES
########################################################################
# Cria um retangulo como moldura
#
psxy <<FIM -L -R0/16.1/0/4.8 -Jx1 -K -P -X0 -Y0> $PSFILE
0	0	
16.1	0
16.1	4.8
0	4.8
FIM
########################################################################
# Contorna, cria o titulo...
#
pscontour <<FIM -V -B60f15N:"$TITULO": -R$XMIN/$XMAX/$YMIN/0 -Jx.02 -C$CORES -W4 -G2 -I -K -O -X0.5 -Y0.5 >> $PSFILE
45	 -30	 1279
60	 -45	 899
75	 -60	 907
90	 -75	 658
105	 -90	 499
120	 -105	 341
135	 -120	 410
75	 -30	 1014
90	 -45	 950
105	 -60	 721
120	 -75	 558
135	 -90	 357
150	 -105	 404
165	 -120	 441
105	 -30	 1016
120	 -45	 748
135	 -60	 617
150	 -75	 457
165	 -90	 400
180	 -105	 544
195	 -120	 746
135	 -30	 725
150	 -45	 732
165	 -60	 472
180	 -75	 348
195	 -90	 424
210	 -105	 562
225	 -120	 318
165	 -30	 837
180	 -45	 614
195	 -60	 379
210	 -75	 580
225	 -90	 505
240	 -105	 324
255	 -120	 505
195	 -30	 578
210	 -45	 373
225	 -60	 447
240	 -75	 562
255	 -90	 424
270	 -105	 412
285	 -120	 386
225	 -30	 304
240	 -45	 393
255	 -60	 550
270	 -75	 446
285	 -90	 465
300	 -105	 431
315	 -120	 494
255	 -30	 250
270	 -45	 410
285	 -60	 393
300	 -75	 449
315	 -90	 449
330	 -105	 509
345	 -120	 1224
285	 -30	 225
300	 -45	 237
315	 -60	 328
330	 -75	 364
345	 -90	 447
360	 -105	 1093
375	 -120	 1654
315	 -30	 146
330	 -45	 240
345	 -60	 325
360	 -75	 449
375	 -90	 1163
390	 -105	 1896
405	 -120	 1479
345	 -30	 133
360	 -45	 198
375	 -60	 335
390	 -75	 977
405	 -90	 1739
420	 -105	 1336
435	 -120	 638
375	 -30	 62
390	 -45	 126
405	 -60	 456
420	 -75	 896
435	 -90	 757
450	 -105	 389
465	 -120	 192
405	 -30	 59
420	 -45	 241
435	 -60	 564
450	 -75	 571
465	 -90	 247
480	 -105	 127
495	 -120	 99
435	 -30	 121
450	 -45	 309
465	 -60	 367
480	 -75	 144
495	 -90	 95
510	 -105	 70
525	 -120	 40
465	 -30	 246
480	 -45	 319
495	 -60	 139
510	 -75	 68
525	 -90	 72
540	 -105	 41
555	 -120	 37
495	 -30	 755
510	 -45	 573
525	 -60	 315
540	 -75	 106
555	 -90	 89
570	 -105	 72
585	 -120	 108
FIM
#
##############################################################################
# Faz as linhas indicativas do niveis n1, n2 ...
# Truque implicito: as "barras de erro" estao "clipadas" em XMIN e XMAX.
#
psxy <<FIM -V -Ex0 -R -Jx -O -K >> $PSFILE
0      -30.0	 15
0      -45.0  	 30
0      -60.0  	 45
0      -75.0  	 60
0      -90.0  	 75
0      -105.  	 90
0      -120.  	 105
630    -30.0	 105
630    -45.0     90
630    -60.0     75
630    -75.0     60
630    -90.0     45
630    -105.     30
630    -120.     15
FIM
#
##############################################################################
# Anota "n=1", ...
#
pstext <<FIM -V -R -Jx -N -Y.05 -O -K>> $PSFILE
0      -30.0	 8      0      7 	1 	n=1
0      -45.0  	 8      0      7	1       n=2
0      -60.0  	 8      0      7	1       n=3
0      -75.0  	 8      0      7	1       n=4
0      -90.0  	 8      0      7	1       n=5
0      -105.  	 8      0      7	1       n=6
0      -120.  	 8      0      7	1       n=7
630    -30.0	 8      0      7	3       n=1
630    -45.0	 8      0      7	3       n=2
630    -60.0   	 8      0      7	3       n=3
630    -75.0     8      0      7	3       n=4
630    -90.0     8      0      7	3       n=5
630    -105.     8      0      7	3       n=6
630    -120.     8      0      7	3       n=7
FIM
#
##############################################################################
# Cria a escala de cores.
#
gmtset  ANOT_FONT_SIZE 8 LABEL_FONT_SIZE 8
psscale -C$CORES -D13.5/1.5/3/.6 -B:"(ohm.m)": -O  >> $PSFILE
##############################################################################
##############################################################################
